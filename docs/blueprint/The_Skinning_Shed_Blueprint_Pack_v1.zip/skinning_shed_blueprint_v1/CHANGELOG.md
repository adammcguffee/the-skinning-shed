# CHANGELOG

## v1 — 2026-01-22
Initial blueprint pack created. Frozen scope and rules for The Skinning Shed, including Trophy Wall, Weather/Activity/Research, Land listings, and The Swap Shop.
